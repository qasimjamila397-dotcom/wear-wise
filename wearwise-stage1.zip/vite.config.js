import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// "base" must match your GitHub repository name, because GitHub Pages
// serves the site at https://YOUR-NAME.github.io/wearwise/
export default defineConfig({
  base: "/wearwise/",
  plugins: [react()],
});
